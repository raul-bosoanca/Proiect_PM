Linear Servo Actuator (SG90) by ahmet39 on Thingiverse: https://www.thingiverse.com/thing:6025341

Summary:
It is a work in progress.
